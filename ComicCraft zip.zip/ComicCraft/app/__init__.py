"""
ComicCraft application package.
"""