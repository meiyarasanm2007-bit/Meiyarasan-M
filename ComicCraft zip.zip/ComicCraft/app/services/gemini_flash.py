import json
import re
from typing import Any, Dict, List

from app.config import settings


def _extract_json(text: str) -> Any:
    """
    Extract JSON from normal JSON output or fenced Markdown JSON.
    """
    text = text.strip()

    # Remove Markdown code fences.
    text = re.sub(
        r"^```(?:json)?\s*",
        "",
        text,
        flags=re.IGNORECASE,
    )

    text = re.sub(
        r"\s*```$",
        "",
        text,
    )

    # Try normal JSON first.
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try to find a JSON object.
    object_match = re.search(
        r"\{.*\}",
        text,
        flags=re.DOTALL,
    )

    if object_match:
        try:
            return json.loads(object_match.group(0))
        except json.JSONDecodeError:
            pass

    # Try to find a JSON array.
    array_match = re.search(
        r"\[.*\]",
        text,
        flags=re.DOTALL,
    )

    if array_match:
        try:
            return json.loads(array_match.group(0))
        except json.JSONDecodeError:
            pass

    raise ValueError("Gemini returned invalid JSON.")


def generate_outline(
    story_prompt: str,
    character_name: str,
    setting: str,
    tone: str,
    art_style: str,
    panel_count: int,
) -> Dict[str, Any]:
    """
    Use Gemini to create the comic panel outline.
    """

    if not settings.gemini_api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is missing. Add it to your .env file."
        )

    from google import genai

    client = genai.Client(
        api_key=settings.gemini_api_key
    )

    prompt = f"""
You are a professional comic storyboard writer.

Create a comic story outline with exactly {panel_count} panels.

User story idea:

{story_prompt}

Main character:

{character_name}

Setting:

{setting}

Tone:

{tone}

Art style:

{art_style}

Return ONLY valid JSON.

Use exactly this structure:

{{
  "title": "Short comic title",
  "panels": [
    {{
      "panel_number": 1,
      "scene": "Description of what happens visually",
      "image_prompt": "Detailed visual prompt for an image generator"
    }}
  ]
}}

Requirements:

1. Create exactly {panel_count} panels.
2. The story must have a clear beginning, middle, and ending.
3. Maintain character consistency.
4. Make each panel visually different.
5. Image prompts should describe characters, environment, lighting, composition, emotion and comic style.
6. Do not include Markdown.
"""

    response = client.models.generate_content(
        model=settings.gemini_outline_model,
        contents=prompt,
    )

    raw_text = getattr(response, "text", None)

    if not raw_text:
        raise RuntimeError(
            "Gemini did not return any outline text."
        )

    data = _extract_json(raw_text)

    if not isinstance(data, dict):
        raise ValueError(
            "Gemini outline must be a JSON object."
        )

    panels: List[Dict[str, Any]] = data.get(
        "panels",
        [],
    )

    if len(panels) != panel_count:
        raise ValueError(
            f"Expected {panel_count} panels, "
            f"but Gemini returned {len(panels)}."
        )

    for index, panel in enumerate(panels, start=1):
        panel["panel_number"] = index

        panel.setdefault(
            "scene",
            f"Scene {index}",
        )

        panel.setdefault(
            "image_prompt",
            panel["scene"],
        )

    data.setdefault(
        "title",
        "My AI Comic",
    )

    data["panels"] = panels

    return data