"""
ComicCraft service modules.
"""